# flutter_launcher_icons

A new example Flutter project to quickly test flutter_launcher_icons.

Before being able to run this example you need to navigate to this directory and run the following command

```
flutter create .
```
