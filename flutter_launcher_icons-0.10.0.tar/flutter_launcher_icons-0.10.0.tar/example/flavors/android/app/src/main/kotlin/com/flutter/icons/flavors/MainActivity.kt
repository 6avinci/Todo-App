package com.flutter.icons.flavors

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
