# example_with_flavors

A new Flutter project to showcase how to use different icons

## How to run this project

Before being able to run this example you need to navigate to this directory and run the following command

```
flutter create .
```

This project has the following flavors:

- production: `flutter run --flavor production`
- development: `flutter run --flavor development`
- integration: `flutter run --flavor integration`
